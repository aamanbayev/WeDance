<template>
  <WList :id="$route.params.id" />
</template>
