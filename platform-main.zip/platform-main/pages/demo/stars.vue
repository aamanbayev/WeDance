<template>
  <div class="p-4">
    <TStars :item="{}" />
  </div>
</template>
