## Tips for Making Successful Posts on WeDance

#### TITLE

- Make it easy to understand and enticing to click.
- Asking a question? Put it right in the title.

#### BODY

- Keep it short and sweet.
- Use [widgets](https://wedance.vip/markdown), including images and videos.
- Preview your post to make sure it looks good.

#### SHARING

- Post in the relevant group to get more readers.
- Share your posts on Twitter or with friends.
