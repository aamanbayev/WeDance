<template>
  <DefaultLayout no-container />
</template>

<script>
import DefaultLayout from '~/layouts/default'

export default {
  name: 'MinimalLayout',
  components: {
    DefaultLayout,
  },
}
</script>
